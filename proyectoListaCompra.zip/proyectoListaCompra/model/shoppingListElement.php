<?php
class shoppingListElement
{
private int $idProduct;
private string $name;
private float $quantity;
private float $price;
private string $tipoProducto;

public function __construct(int $idProduct, string $name, float $quantity, float $price, string $tipoProducto)
{
    $this->idProduct = $idProduct;
    $this->name = $name;
    $this->quantity = $quantity;
    $this->price = $price;
    $this->tipoProducto = $tipoProducto;
}
public function getIdProduct()
{
    return $this->idProduct;
}
public function getName()
{
    return $this->name;
}
public function getQuantity()
{
    return $this->quantity;
}
public function getPrice()
{
    return $this->price;
}
public function setIdProduct(int $idProduct)
{
    $this->idProduct = $idProduct;
}
public function setName(string $name)
{
    $this->name = $name;
}
public function setQuantity(float $quantity)
{
    $this->quantity = $quantity;
}
public function setPrice(float $price)
{
    $this->price = $price;
}
public function getTipoProducto()
{
    return $this->tipoProducto;
}
public function setTipoProducto(string $tipoProducto)
{
    return $this->tipoProducto = $tipoProducto;
}
}
?>