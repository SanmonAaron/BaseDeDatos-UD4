<?php
include_once("model/user.php");
$user = new User(1, "Nom usuari","correu@correu.com","/imagenes/avatar.png");
?>
<article class="panel is-primary">
    <p class="panel-heading" style="text-align: center;">
        Información del usuario
    </p>
    <div class="box">
        <div>
            <h2><?= $user->getName() ?></h2>
            <h3><?= $user->getEmail() ?></h3>
            <div style="text-align: center;"><img src=<?= $user->getAvatarImage() ?> width="200" height="200"></div>
        </div>
    </div>
</article>