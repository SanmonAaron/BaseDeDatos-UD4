<?php
include_once("model/shoppingListElement.php");
$shoppingListElements = array();
$shoppingListElements[0] = new shoppingListElement(1,"Peras",2,1,"Frutas");
$shoppingListElements[1] = new shoppingListElement(1,"Uvas",3,2,"Frutas");
$shoppingListElements[2] = new shoppingListElement(1,"Cerezas",3,1.5,"Frutas");
$shoppingListName = "Lista molona";
?>
<article class="panel is-primary">
    <p class="panel-heading" style="text-align: center;">
        Lista de la Compra = <i><?= $shoppingListName ?></i>
    </p>
    <div class="box">
        <table class="table is-fullwidth is-bordered is-striped is-narrow is-hoverable is-fullwidth">
            <thead>
                <tr>
                    <th>Producto</th>
                    <th>Cantidad</th>
                    <th>Categoria</th>
                    <th>Total</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $total = 0;
                foreach($shoppingListElements as $shoppingItem){
                    $productoTotal = $shoppingItem->getQuantity() * $shoppingItem->getPrice();
                    $total = $total + $productoTotal;
                    print("<tr><td>{$shoppingItem->getName()}</td><td>{$shoppingItem->getQuantity()}</td><td>{$shoppingItem->getTipoProducto()}</td><td>$productoTotal</td></tr>");
                }
                print("<tfoot><th colspan=\"3\">TOTAL</th><th>$total</th></tfoot>");
                ?>
            </tbody>
    </div>
</article>